import { watchFile, unwatchFile } from 'fs';
import fs from 'fs';
import chalk from 'chalk';
import { fileURLToPath } from 'url';

// Global Settings
global.setting = {
  autoclear: false,
  addReply: true, // Tambahkan balasan dengan thumbnail di pesan
};

// Owner Information
global.owner = [
  ['6283842478119', 'MrTwo', true],
];

// Bot Information
global.info = {
  nomerbot: '6283852478119',
  pairingNumber: '6283851478119',
  nameown: 'MrTwo',
  nomerown: '6283852478119',
  packname: 'sticker by MrTwo',
  author: 'MrTwo',
  namebot: 'MrBotUwU', 
  wm: 'MrBot By MrTwo',
  stickpack: 'YTB MrTwo',
  stickauth: 'S U B S C R I B E',
};

// URLs
global.url = {
  profil: 'https://files.catbox.moe/ijeati.jpg',
  did: 'https://telegra.ph/file/fdc1a8b08fe63520f4339.jpg',
  rules: 'https://telegra.ph/file/afcfa712bd09f4fcf027a.jpg',
  thumbnail: 'https://files.catbox.moe/ijeati.jpg',
  thumb: 'https://files.catbox.moe/ijeati.jpg',
  logo: 'https://telegra.ph/file/07428fea2fd4dccaab65f.jpg',
  unReg: 'https://telegra.ph/file/ef02d1fdd59082d05f08d.jpg',
  registrasi: 'https://itzpire.com/file/6ead5b50254b.jpg',
  confess: 'https://telegra.ph/file/03cabea082a122abfa5be.jpg',
  akses: 'https://telegra.ph/file/6c7b9ffbdfb0096e1db3e.jpg',
  wel: 'https://telegra.ph/file/9dbc9c39084df8691ebdd.mp4', // Welcome GIF
  bye: 'https://telegra.ph/file/1c05b8c019fa525567d01.mp4', // Goodbye GIF
  sound: 'https://media.vocaroo.com/mp3/1awgSZYHXP3B', // Audio menu
  sig: '',
  sgh: '',
  sgc: 'https://whatsapp.com/channel/0029VaHPYh6LNSa81M9Xcq1K',
};

// Payment Information
global.payment = {
  psaweria: 'https://saweria.co/',
  ptrakterr: '-',
  pdana: '',
};

// Tokopay Integration
global.tokopay = {
  merchantID: '-',
  secretKey: '-',
  link: 'https://api.tokopay.id',
};

// SMM Information
global.smm = {
  apiKey: '-',
  apiId: '-',
  link: 'https://valerieconnect.shop',
};

// Messages
global.msg = {
  wait: '鈴憋笍 *Mohon bersabar*\n\> Sedang menjalankan perintah dari *User*!',
  eror: '馃 *Information Bot*\n\> Mohon maaf atas ketidaknyamanan dalam menggunakan *Nightmare Bot* . Ada kesalahan dalam sistem saat menjalankan perintah.',
};

// RPG Configuration
global.multiplier = 69;
global.rpg = {
  emoticon(string) {
    const emot = {
      agility: '馃じ鈥嶁檪锔�',
      arc: '馃徆',
      armor: '馃ゼ',
      bank: '馃彟',
      bibitanggur: '馃崌',
      bibitapel: '馃崕',
      bibitjeruk: '馃崐',
      bibitmangga: '馃キ',
      bibitpisang: '馃崒',
      bow: '馃徆',
      bull: '馃悆',
      cat: '馃悎',
      chicken: '馃悡',
      common: '馃摝',
      cow: '馃悇',
      crystal: '馃敭',
      darkcrystal: '鈾狅笍',
      diamond: '馃拵',
      dog: '馃悤',
      dragon: '馃悏',
      elephant: '馃悩',
      emerald: '馃挌',
      exp: '鉁夛笍',
      fishingrod: '馃帲',
      fox: '馃',
      gems: '馃崁',
      giraffe: '馃',
      gold: '馃憫',
      health: '鉂わ笍',
      horse: '馃悗',
      intelligence: '馃',
      iron: '鉀擄笍',
      keygold: '馃攽',
      keyiron: '馃棟锔�',
      knife: '馃敧',
      legendary: '馃梼锔�',
      level: '馃К',
      limit: '馃寣',
      lion: '馃',
      magicwand: '鈿曪笍',
      mana: '馃獎',
      money: '馃挼',
      mythic: '馃棾锔�',
      pet: '馃巵',
      petFood: '馃崠',
      pickaxe: '鉀忥笍',
      pointxp: '馃摟',
      potion: '馃イ',
      rock: '馃',
      snake: '馃悕',
      stamina: '鈿�',
      strength: '馃鈥嶁檧锔�',
      string: '馃暩锔�',
      superior: '馃捈',
      sword: '鈿旓笍',
      tiger: '馃悈',
      trash: '馃棏',
      uncommon: '馃巵',
      upgrader: '馃О',
      wood: '馃',
    };
    const result = Object.keys(emot).find((key) => string.toLowerCase().includes(key));
    return result ? emot[result] : '';
  },
};

// API Configuration
global.api = {
  btch: '-',
};
global.APIs = {
  btch: 'https://api.botcahx.eu.org',
};
global.APIKeys = {
  'https://api.botcahx.eu.org': '-',
};

// Watch for File Changes
let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
  unwatchFile(file);
  console.log(chalk.redBright("Update 'settings.js'"));
  import(`${file}?update=${Date.now()}`);
});